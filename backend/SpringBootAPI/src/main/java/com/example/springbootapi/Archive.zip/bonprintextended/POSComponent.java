package com.example.springbootapi.bonprintextended;

public interface POSComponent {
    byte[] toBytes();
}
