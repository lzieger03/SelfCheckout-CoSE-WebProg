package com.example.springbootapi.bonprintextended;

public enum POSStyle {
    BOLD, ITALIC, UNDERLINE, BIG, SMALL, CENTER, LEFT, RIGHT
}
